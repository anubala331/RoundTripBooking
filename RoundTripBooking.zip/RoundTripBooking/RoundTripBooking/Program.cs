﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
namespace Problem
{
    public enum RoundTrip
    {
        Autobus = 50, Train = 80, Plane = 200,
    }

    class Engine
    {

        static void Main(string[] args)
        {
            try
            {
                Engine e = new Engine();
                e.Start();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            // Console.ReadKey();
        }

        public int GetEnumVal(string mode)
        {
            int fare = (int)Enum.Parse(typeof(RoundTrip), mode);
            return fare;
        }

        public void DisplayMenu(int total, decimal avg, Dictionary<string, int> TripCount)
        {
            Console.WriteLine("______________________________________________");
            Console.WriteLine("<Standard Menu>");
            Console.WriteLine("RoundTrip From Italy to Florence:");
            var modes = Enum.GetNames(typeof(RoundTrip));

            foreach (string mode in modes)
            {
                int fare = GetEnumVal(mode);
                Console.WriteLine(mode + " : " + fare.ToString("c"));
            }
            Console.WriteLine("______________________________________________");
            Console.WriteLine("\r\n<HISTORY OF BOOKINGS>");

            if (total > 0 || avg > 0)
                BookingDetails(total, avg, TripCount);
            else
                Console.WriteLine("No Record Found\r\n");
        }

        public void GoingToBook(string valueString, ref int total, ref decimal avg, Dictionary<string, int> TripCount)
        {
            TripCount[valueString] += 1;
            TripCount["Total"] += 1;

            total += GetEnumVal(valueString);

            avg = (decimal)total / (TripCount["Total"]);

            Console.WriteLine("\r\nYour Booking has been Confirmed!");
        }

        public void BookingDetails(int total, decimal avg, Dictionary<string, int> TripCount)
        {
            Console.WriteLine("______________________________________________");
            Console.WriteLine("\r\nBooking Details Are : ");

            Console.WriteLine("Trips Count per Mode(till now)");
            var modes = TripCount.Keys.ToList();
            foreach (var key in modes)
            {
                Console.WriteLine(key + " : " + TripCount[key]);
            }

            Console.WriteLine("\nTotal Money Spent(till now): " + total.ToString("c"));
            Console.WriteLine("Average(total): {0}\r\n", avg.ToString("c"));
            Console.WriteLine("______________________________________________\r\n");
        }

        public void Start()
        {
            Console.OutputEncoding = Encoding.UTF8;
            CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("fr-FR"); //need to change it for euros

            char choice = 'Y';
            int total = 0;
            decimal avg = 0;
            var TripCount = new Dictionary<string, int>()
            {
                {"Autobus", 0}, {"Train", 0} , {"Plane", 0} , {"Total", 0}
            };

            bool status, flag;

            do
            {
                DisplayMenu(total, avg, TripCount); // to present menu//

                string valueString = string.Empty;

                Console.WriteLine("Book a New Ticket(RoundTrip)");
                do
                {
                    Console.WriteLine("How do you want to go? ");
                    Console.Write("Please Enter:  B/b for Autobus || T/t for Train || P/p for Plane\r\n");//to ease the use for user
                    valueString = Console.ReadLine().ToLower();
                } while (valueString != "b" && valueString != "t" && valueString != "p");

                switch (valueString)
                {
                    case "b":
                        valueString = "Autobus";
                        break;
                    case "t":
                        valueString = "Train";
                        break;
                    case "p":
                        valueString = "Plane";
                        break;
                    default:
                        break;
                }

                GoingToBook(valueString, ref total, ref avg, TripCount); //update booking information

                BookingDetails(total, avg, TripCount); //get history of tickets

                Console.Write("Continue to book Another Trip: Press Y/y to continue \r\n");


                status = char.TryParse(Console.ReadLine(), out choice);

                if (status && Char.ToUpper(choice) == 'Y')//additional steps of code added just to add if statement
                    flag = true;
                else
                    flag = false;
            } while (flag);

            Console.WriteLine("Thankyou For Visiting!");
        }
    }
}




